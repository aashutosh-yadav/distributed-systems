// Package test is the harness for your MapReduce implementation. It builds
// cmd/mr, launches real coordinator and worker OS processes, and checks the
// results. Nothing here imports your code; it only runs the binary.
//
//	go test ./test -v            (or: make test)
//	MR_RACE=1 go test ./test -v  (or: make race)   builds with the race detector
//	go test ./test -v -run Crash (one test)
package test

import (
	"context"
	"fmt"
	"math/rand"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

var binPath string

func TestMain(m *testing.M) {
	wd, _ := os.Getwd()
	root := filepath.Dir(wd)
	tmp, err := os.MkdirTemp("", "mrbin")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	binPath = filepath.Join(tmp, "mr")
	args := []string{"build"}
	if os.Getenv("MR_RACE") != "" {
		args = append(args, "-race")
	}
	args = append(args, "-o", binPath, "./cmd/mr")
	cmd := exec.Command("go", args...)
	cmd.Dir = root
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		fmt.Fprintln(os.Stderr, "build failed:", err)
		os.Exit(1)
	}
	code := m.Run()
	os.RemoveAll(tmp)
	os.Exit(code)
}

// ------------------------------------------------------------ helpers

type proc struct {
	cmd    *exec.Cmd
	done   chan struct{}
	exited time.Time
}

func start(ctx context.Context, dir string, env []string, args ...string) *proc {
	cmd := exec.CommandContext(ctx, binPath, args...)
	cmd.Dir = dir
	cmd.Env = append(os.Environ(), env...)
	if testing.Verbose() {
		cmd.Stderr = os.Stderr
	}
	if err := cmd.Start(); err != nil {
		panic(err)
	}
	p := &proc{cmd: cmd, done: make(chan struct{})}
	go func() {
		cmd.Wait()
		p.exited = time.Now()
		close(p.done)
	}()
	return p
}

func waitProc(t *testing.T, p *proc, limit time.Duration, what string) {
	t.Helper()
	select {
	case <-p.done:
	case <-time.After(limit):
		t.Fatalf("%s did not finish within %v (does Done() become true? are tasks handed out and reported?)", what, limit)
	}
}

func freeAddr(t *testing.T) string {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := l.Addr().String()
	l.Close()
	return addr
}

func waitListening(t *testing.T, addr string, coord *proc) {
	t.Helper()
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		if c, err := net.Dial("tcp", addr); err == nil {
			c.Close()
			return
		}
		select {
		case <-coord.done:
			t.Fatal("coordinator exited before listening")
		default:
		}
		time.Sleep(50 * time.Millisecond)
	}
	t.Fatal("coordinator never started listening on " + addr)
}

// makeInputs writes deterministic text files using a 50-word, letters-only
// vocabulary (the apps split on non-letters).
func makeInputs(t *testing.T, dir string, nFiles, nWords int) []string {
	t.Helper()
	rng := rand.New(rand.NewSource(1))
	vocab := make([]string, 50)
	for i := range vocab {
		vocab[i] = "w" + string(rune('a'+i/26)) + string(rune('a'+i%26))
	}
	var files []string
	for i := 0; i < nFiles; i++ {
		var sb strings.Builder
		for j := 0; j < nWords; j++ {
			sb.WriteString(vocab[rng.Intn(len(vocab))])
			if j%10 == 9 {
				sb.WriteString("\n")
			} else {
				sb.WriteString(" ")
			}
		}
		name := filepath.Join(dir, fmt.Sprintf("input-%02d.txt", i))
		if err := os.WriteFile(name, []byte(sb.String()), 0o644); err != nil {
			t.Fatal(err)
		}
		files = append(files, name)
	}
	return files
}

func reference(t *testing.T, app string, files []string) []string {
	t.Helper()
	args := append([]string{"-role=sequential", "-app=" + app}, files...)
	out, err := exec.Command(binPath, args...).Output()
	if err != nil {
		t.Fatalf("sequential reference failed: %v", err)
	}
	return splitSorted(string(out))
}

func splitSorted(s string) []string {
	var lines []string
	for _, l := range strings.Split(s, "\n") {
		if l != "" {
			lines = append(lines, l)
		}
	}
	sort.Strings(lines)
	return lines
}

func collectOutput(t *testing.T, dir string) []string {
	t.Helper()
	paths, _ := filepath.Glob(filepath.Join(dir, "mr-out-*"))
	if len(paths) == 0 {
		t.Fatal("no mr-out-* files were produced")
	}
	var all []string
	for _, p := range paths {
		b, err := os.ReadFile(p)
		if err != nil {
			t.Fatal(err)
		}
		all = append(all, splitSorted(string(b))...)
	}
	sort.Strings(all)
	return all
}

func checkEqual(t *testing.T, got, want []string) {
	t.Helper()
	if reflect.DeepEqual(got, want) {
		return
	}
	t.Errorf("output differs from sequential reference: got %d lines, want %d", len(got), len(want))
	n := 0
	gs, ws := map[string]bool{}, map[string]bool{}
	for _, l := range got {
		gs[l] = true
	}
	for _, l := range want {
		ws[l] = true
	}
	for _, l := range want {
		if !gs[l] && n < 5 {
			t.Errorf("  missing: %q", l)
			n++
		}
	}
	for _, l := range got {
		if !ws[l] && n < 10 {
			t.Errorf("  unexpected: %q", l)
			n++
		}
	}
	t.FailNow()
}

type job struct {
	ctx     context.Context
	dir     string
	files   []string
	env     []string
	addr    string
	nReduce int
	coord   *proc
}

// newJob prepares inputs and starts the coordinator.
func newJob(t *testing.T, nFiles, nReduce, timeoutMs int, total time.Duration) *job {
	t.Helper()
	dir := t.TempDir()
	ctx, cancel := context.WithTimeout(context.Background(), total)
	t.Cleanup(cancel) // runs before TempDir removal: kills stray processes first
	j := &job{ctx: ctx, dir: dir, nReduce: nReduce}
	j.files = makeInputs(t, dir, nFiles, 3000)
	j.env = []string{"MR_TASK_TIMEOUT_MS=" + strconv.Itoa(timeoutMs), "MR_LOGDIR=" + dir}
	j.addr = freeAddr(t)
	args := []string{"-role=coordinator", "-addr=" + j.addr, "-nreduce=" + strconv.Itoa(nReduce)}
	j.coord = start(ctx, dir, j.env, append(args, j.files...)...)
	waitListening(t, j.addr, j.coord)
	return j
}

func (j *job) worker(app string) *proc {
	return start(j.ctx, j.dir, j.env, "-role=worker", "-coord="+j.addr, "-app="+app)
}

func (j *job) workers(app string, n int) []*proc {
	var ps []*proc
	for i := 0; i < n; i++ {
		ps = append(ps, j.worker(app))
	}
	return ps
}

// runStandard: coordinator + n workers, wait for completion, all must exit.
func runStandard(t *testing.T, app string, nFiles, nWorkers, nReduce, timeoutMs int) *job {
	j := newJob(t, nFiles, nReduce, timeoutMs, 120*time.Second)
	ws := j.workers(app, nWorkers)
	waitProc(t, j.coord, 30*time.Second, "coordinator")
	for i, w := range ws {
		waitProc(t, w, 15*time.Second, fmt.Sprintf("worker %d (should exit after the job is done)", i))
	}
	return j
}

type event struct {
	kind, ev string
	ts       int64
}

func readEvents(t *testing.T, dir string) []event {
	t.Helper()
	b, err := os.ReadFile(filepath.Join(dir, "timing.log"))
	if err != nil {
		t.Fatalf("no timing log: %v", err)
	}
	var evs []event
	for _, l := range splitSorted(string(b)) {
		f := strings.Fields(l)
		ts, _ := strconv.ParseInt(f[2], 10, 64)
		evs = append(evs, event{f[0], f[1], ts})
	}
	return evs
}

func maxConcurrent(evs []event, kind string) int {
	var mine []event
	for _, e := range evs {
		if e.kind == kind {
			mine = append(mine, e)
		}
	}
	sort.Slice(mine, func(i, j int) bool {
		if mine[i].ts != mine[j].ts {
			return mine[i].ts < mine[j].ts
		}
		return mine[i].ev == "end" && mine[j].ev == "start" // ends first on ties
	})
	cur, best := 0, 0
	for _, e := range mine {
		if e.ev == "start" {
			cur++
			if cur > best {
				best = cur
			}
		} else {
			cur--
		}
	}
	return best
}

func bound(evs []event, kind, ev string, wantMax bool) int64 {
	var r int64
	first := true
	for _, e := range evs {
		if e.kind != kind || e.ev != ev {
			continue
		}
		if first || (wantMax && e.ts > r) || (!wantMax && e.ts < r) {
			r, first = e.ts, false
		}
	}
	return r
}

// -------------------------------------------------------------- tests

func TestWc(t *testing.T) {
	j := runStandard(t, "wc", 8, 3, 10, 5000)
	checkEqual(t, collectOutput(t, j.dir), reference(t, "wc", j.files))
}

func TestIndexer(t *testing.T) {
	j := runStandard(t, "indexer", 8, 3, 10, 5000)
	checkEqual(t, collectOutput(t, j.dir), reference(t, "indexer", j.files))
}

func TestMapParallel(t *testing.T) {
	j := runStandard(t, "timing", 6, 3, 4, 10000)
	evs := readEvents(t, j.dir)
	if n := maxConcurrent(evs, "map"); n < 2 {
		t.Fatalf("map tasks never overlapped (max concurrent = %d); 3 workers should run maps in parallel", n)
	}
}

func TestReduceParallel(t *testing.T) {
	j := runStandard(t, "timing", 6, 3, 4, 10000)
	evs := readEvents(t, j.dir)
	if n := maxConcurrent(evs, "reduce"); n < 2 {
		t.Fatalf("reduce tasks never overlapped (max concurrent = %d)", n)
	}
	if bound(evs, "map", "end", true) > bound(evs, "reduce", "start", false) {
		t.Fatal("a reduce started before the last map finished")
	}
	var want []string
	for i := 0; i < 8; i++ {
		want = append(want, fmt.Sprintf("k%d 6", i))
	}
	sort.Strings(want)
	checkEqual(t, collectOutput(t, j.dir), want)
}

func TestJobCount(t *testing.T) {
	j := runStandard(t, "jobcount", 6, 3, 5, 5000)
	want := reference(t, "wc", j.files)
	checkEqual(t, collectOutput(t, j.dir), want)

	b, _ := os.ReadFile(filepath.Join(j.dir, "jobs.log"))
	maps, reduces := 0, 0
	for _, l := range strings.Split(string(b), "\n") {
		switch {
		case strings.HasPrefix(l, "map "):
			maps++
		case strings.HasPrefix(l, "reduce "):
			reduces++
		}
	}
	if maps != len(j.files) {
		t.Errorf("Map ran %d times, want exactly %d (one per file): extra tasks scheduled without any crash", maps, len(j.files))
	}
	if reduces != len(want) {
		t.Errorf("Reduce ran %d times, want exactly %d (one per key): a reduce task ran twice", reduces, len(want))
	}
}

// No worker may exit while work remains. With only 2 map files and 3 workers,
// one worker is told to "wait" during the map phase; a buggy worker quits.
func TestEarlyExit(t *testing.T) {
	j := newJob(t, 2, 4, 10000, 120*time.Second)
	ws := j.workers("timing", 3)
	waitProc(t, j.coord, 30*time.Second, "coordinator")
	for _, w := range ws {
		waitProc(t, w, 15*time.Second, "worker")
	}
	lastWork := time.Unix(0, bound(readEvents(t, j.dir), "reduce", "end", true))
	for i, w := range ws {
		if w.exited.Before(lastWork) {
			t.Errorf("worker %d exited %v before the last reduce finished: workers must not quit while work may remain", i, lastWork.Sub(w.exited))
		}
	}
}

func TestCrashWorker(t *testing.T) {
	j := newJob(t, 8, 5, 2000, 180*time.Second)
	var wg sync.WaitGroup
	for i := 0; i < 3; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				select {
				case <-j.coord.done:
					return
				default:
				}
				w := j.worker("crash")
				select {
				case <-w.done: // crashed or finished: start a replacement
				case <-j.coord.done:
					return
				}
				time.Sleep(50 * time.Millisecond)
			}
		}()
	}
	waitProc(t, j.coord, 150*time.Second, "coordinator (with crashing workers)")
	wg.Wait()
	checkEqual(t, collectOutput(t, j.dir), reference(t, "wc", j.files))
}
