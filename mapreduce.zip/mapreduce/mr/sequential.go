package mr

import (
	"fmt"
	"os"
	"sort"
)

// RunSequential is the reference implementation: no processes, no network,
// no failures. It returns the final output lines ("key value"), sorted.
//
// The tests compare your distributed output against this.
func RunSequential(files []string, mapf MapFunc, reducef ReduceFunc) []string {
	var kvs []KeyValue
	for _, f := range files {
		data, err := os.ReadFile(f)
		if err != nil {
			panic(err)
		}
		kvs = append(kvs, mapf(f, string(data))...)
	}

	groups := make(map[string][]string)
	for _, kv := range kvs {
		groups[kv.Key] = append(groups[kv.Key], kv.Value)
	}

	lines := make([]string, 0, len(groups))
	for k, vs := range groups {
		// This is the exact output format your reduce tasks must write.
		lines = append(lines, fmt.Sprintf("%v %v", k, reducef(k, vs)))
	}
	sort.Strings(lines)
	return lines
}
