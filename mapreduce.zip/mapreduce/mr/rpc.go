package mr

import (
	"bytes"
	"encoding/json"
	"log"
	"net/http"
	"time"
)

// ---------------------------------------------------------------------------
// Messages between worker and coordinator. These are a STARTING POINT:
// add, remove, or rename fields as your design needs.
//
// Fields must be capitalized or encoding/json will not send them.
// ---------------------------------------------------------------------------

// Task types the coordinator can reply with.
const (
	TaskMap    = "map"
	TaskReduce = "reduce"
	TaskWait   = "wait" // nothing to do right now, ask again soon
	TaskExit   = "exit" // job finished, worker should quit
)

type GetTaskArgs struct {
	// TODO: does the coordinator need to know who is asking?
}

type GetTaskReply struct {
	TaskType string
	TaskID   int
	File     string // map tasks: the input file
	NMap     int    // reduce tasks need to know how many map tasks there were
	NReduce  int    // map tasks need to know how many buckets to write
}

type ReportDoneArgs struct {
	TaskType string
	TaskID   int
}

type ReportDoneReply struct{}

// ---------------------------------------------------------------------------
// Transport (provided). Workers talk to the coordinator with JSON over HTTP.
// Endpoints: POST /task  and  POST /done  (see coordinator.go serve()).
// ---------------------------------------------------------------------------

var httpClient = &http.Client{Timeout: 5 * time.Second}

// call sends args to http://addr+path and decodes the JSON response into
// reply. It returns false if the coordinator could not be reached or did not
// answer successfully. Pass a zero-valued reply struct.
//
// A false return can mean: coordinator crashed, finished and exited, the
// request was lost, or the reply was lost. You cannot tell which! Think about
// what that means for your design.
func call(addr, path string, args, reply interface{}) bool {
	body, err := json.Marshal(args)
	if err != nil {
		log.Fatalf("call: marshal: %v", err)
	}
	resp, err := httpClient.Post("http://"+addr+path, "application/json", bytes.NewReader(body))
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return false
	}
	return json.NewDecoder(resp.Body).Decode(reply) == nil
}
