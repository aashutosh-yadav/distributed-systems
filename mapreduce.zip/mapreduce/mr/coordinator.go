package mr

import (
	"encoding/json"
	"log"
	"net"
	"net/http"
	"sync"
)

// Coordinator hands out tasks and tracks their progress.
//
// TODO (core part #1): decide what state it needs. Think: per-task status
// (idle / in-progress / done), when each task was handed out, the current
// phase (map -> reduce -> done). Every HTTP handler runs in its own
// goroutine, so everything shared must be protected by mu.
type Coordinator struct {
	mu sync.Mutex

	// TODO: your state here
}

// MakeCoordinator is called once by cmd/mr. files holds one input file per
// map task. It must return quickly (the server runs in the background).
func MakeCoordinator(addr string, files []string, nReduce int) *Coordinator {
	c := &Coordinator{}

	// TODO: initialize your task tables from files and nReduce.

	c.serve(addr)
	return c
}

// GetTask is called when a worker asks for work. Fill in reply.
//
// TODO: lock c.mu; find an idle task (or an in-progress one older than
// TaskTimeout()); mark it in progress; reply with it. If no task can be
// given right now reply TaskWait. If the whole job is finished reply TaskExit.
// Remember: reduce tasks must not start until EVERY map task is done.
func (c *Coordinator) GetTask(args *GetTaskArgs, reply *GetTaskReply) {
	reply.TaskType = TaskWait // stub: replace
}

// ReportDone is called when a worker finishes a task.
//
// TODO: mark the task done. What if it was already done (duplicate/late
// report from a worker you thought was dead)? What if this was the last map
// task? The last reduce task?
func (c *Coordinator) ReportDone(args *ReportDoneArgs, reply *ReportDoneReply) {
}

// Done returns true once the entire job is finished. cmd/mr polls this and
// exits the coordinator process when it becomes true.
func (c *Coordinator) Done() bool {
	// TODO
	return false
}

// serve starts the HTTP server (provided plumbing).
func (c *Coordinator) serve(addr string) {
	mux := http.NewServeMux()

	mux.HandleFunc("/task", func(w http.ResponseWriter, r *http.Request) {
		var args GetTaskArgs
		if err := json.NewDecoder(r.Body).Decode(&args); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		var reply GetTaskReply
		c.GetTask(&args, &reply)
		json.NewEncoder(w).Encode(&reply)
	})

	mux.HandleFunc("/done", func(w http.ResponseWriter, r *http.Request) {
		var args ReportDoneArgs
		if err := json.NewDecoder(r.Body).Decode(&args); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		var reply ReportDoneReply
		c.ReportDone(&args, &reply)
		json.NewEncoder(w).Encode(&reply)
	})

	l, err := net.Listen("tcp", addr)
	if err != nil {
		log.Fatalf("coordinator: listen %s: %v", addr, err)
	}
	go http.Serve(l, mux)
}
