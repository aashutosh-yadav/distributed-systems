package mr

import (
	"time"
)

// Worker runs until the job is finished. It is a client only: it never
// listens on a port, it just repeatedly asks the coordinator for work.
//
// Output file naming the tests expect:
//
//	final output of reduce task Y  ->  mr-out-Y   (in the current directory)
//	one line per key, formatted with fmt.Sprintf("%v %v", key, value)
//
// Intermediate file names (e.g. mr-X-Y) are up to you.
func Worker(coordAddr string, mapf MapFunc, reducef ReduceFunc) {
	for {
		reply := GetTaskReply{}
		if !call(coordAddr, "/task", &GetTaskArgs{}, &reply) {
			// Coordinator unreachable: assume the job is finished.
			return
		}

		// TODO (core parts #2 and #3): switch on reply.TaskType.
		//   TaskMap:    read reply.File, call mapf, partition with
		//               Ihash(key) % reply.NReduce, write intermediate files
		//               (temp file + os.Rename!), then report done.
		//   TaskReduce: read this bucket from every map task, sort by key,
		//               group, call reducef, write mr-out-Y (temp + rename),
		//               then report done.
		//   TaskWait:   sleep briefly and ask again.
		//   TaskExit:   return.
		_ = mapf
		_ = reducef

		time.Sleep(100 * time.Millisecond)
	}
}
