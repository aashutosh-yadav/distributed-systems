// Package mr is where YOU build the MapReduce coordinator and worker.
//
// This file is provided scaffolding: shared types and small helpers.
package mr

import (
	"fmt"
	"hash/fnv"
	"os"
	"strconv"
	"time"
)

// KeyValue is one intermediate record emitted by a Map function.
type KeyValue struct {
	Key   string
	Value string
}

// MapFunc is called once per input file. It returns the intermediate pairs.
type MapFunc func(filename, contents string) []KeyValue

// ReduceFunc is called once per distinct key with all of that key's values.
type ReduceFunc func(key string, values []string) string

// Ihash maps a key to a non-negative int. Use Ihash(key) % nReduce to choose
// which reduce task a key belongs to.
func Ihash(key string) int {
	h := fnv.New32a()
	h.Write([]byte(key))
	return int(h.Sum32() & 0x7fffffff)
}

// TaskTimeout is how long the coordinator should wait for a task before
// assuming its worker died and giving the task to someone else.
//
// Default is 10s. The tests shorten it via the MR_TASK_TIMEOUT_MS environment
// variable so crash tests don't take forever, so USE THIS FUNCTION in your
// coordinator instead of hard-coding 10 seconds.
func TaskTimeout() time.Duration {
	if s := os.Getenv("MR_TASK_TIMEOUT_MS"); s != "" {
		ms, err := strconv.Atoi(s)
		if err != nil || ms <= 0 {
			panic(fmt.Sprintf("bad MR_TASK_TIMEOUT_MS=%q", s))
		}
		return time.Duration(ms) * time.Millisecond
	}
	return 10 * time.Second
}
