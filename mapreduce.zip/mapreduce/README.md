# MapReduce in Go: your own implementation

A distributed word-count-style MapReduce (coordinator + workers, separate OS
processes, HTTP+JSON over localhost), based on the ideas in the 2004 paper.
All scaffolding here is original; you write the core.

## What YOU write (3 files in `mr/`)
| File | Your job |
|---|---|
| `mr/coordinator.go` | State machine: task table, assign tasks, timeouts, phases, `Done()` |
| `mr/worker.go` | Worker loop; map task (partition + atomic write); reduce task |
| `mr/rpc.go` | Adjust the message structs if your design needs more fields |

## What is provided
| Path | Purpose |
|---|---|
| `mr/common.go` | `KeyValue`, `Ihash`, `TaskTimeout()` (10s default, test-overridable) |
| `mr/rpc.go` (bottom) | `call()` HTTP+JSON client helper |
| `mr/coordinator.go` `serve()` | HTTP server exposing `POST /task`, `POST /done` |
| `mr/sequential.go` | Single-process reference implementation |
| `apps/apps.go` | Apps: `wc`, `indexer`, plus test apps `timing`, `jobcount`, `crash` |
| `cmd/mr/main.go` | One binary, three roles: coordinator / worker / sequential |
| `test/mr_test.go` | Test suite (runs real processes; imports none of your code) |

## Contract with the tests
- Coordinator: `MakeCoordinator(addr, files, nReduce)`, `Done()`; use `TaskTimeout()`.
- Worker exits when the coordinator is unreachable or replies `TaskExit`.
- Reduce task Y writes `mr-out-Y` in the current directory, one `"%v %v"` line per key.
- Intermediate file names are yours (suggest `mr-X-Y`), in the current directory.

## Run by hand
    make build
    ./mr -role=sequential -app=wc a.txt b.txt | sort          # reference
    ./mr -role=coordinator -addr=127.0.0.1:8000 -nreduce=5 a.txt b.txt &
    ./mr -role=worker -coord=127.0.0.1:8000 -app=wc &         # repeat for more workers
    cat mr-out-* | sort                                       # must equal reference

## Tests
    make test          # all tests          make race   # with race detector
    make one T=Crash   # a single test      (-v shows process logs)
| Test | Checks |
|---|---|
| TestWc, TestIndexer | Output equals sequential reference |
| TestMapParallel | Map tasks overlap in time with 3 workers |
| TestReduceParallel | Reduces overlap; no reduce starts before the last map ends; output right |
| TestJobCount | Exactly one Map per file and no duplicate reduces when nothing fails |
| TestEarlyExit | Workers never quit while work remains; all exit after the job ends |
| TestCrashWorker | Workers randomly die/stall; job still completes correctly (timeout 2s) |

Known gap: the `crash` app dies inside Map/Reduce, before your code writes
files, so it does not by itself prove your temp-file+rename logic. Test that
manually by `kill -9` on a worker mid-write.

## Next stage: Docker
One binary, so one Dockerfile; compose runs 1 coordinator (`-addr=:8000`) and
N workers (`-coord=coordinator:8000`). Containers don't share a disk, so mount
one shared volume as the working directory for intermediate + output files.
