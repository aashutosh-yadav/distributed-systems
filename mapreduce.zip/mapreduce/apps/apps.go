// Package apps holds the sample MapReduce applications, plus a few special
// ones used by the tests. Applications are compiled in and selected by name
// with -app=NAME (no plugin loading needed).
package apps

import (
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode"

	"mapreduce/mr"
)

type App struct {
	Map    mr.MapFunc
	Reduce mr.ReduceFunc
}

var registry = map[string]App{
	"wc":       {wcMap, wcReduce},
	"indexer":  {indexerMap, indexerReduce},
	"timing":   {timingMap, timingReduce},
	"jobcount": {jobcountMap, jobcountReduce},
	"crash":    {crashMap, crashReduce},
}

// Get returns the application registered under name.
func Get(name string) (App, bool) {
	a, ok := registry[name]
	return a, ok
}

// Names lists the available applications.
func Names() []string {
	var n []string
	for k := range registry {
		n = append(n, k)
	}
	sort.Strings(n)
	return n
}

func words(s string) []string {
	return strings.FieldsFunc(s, func(r rune) bool { return !unicode.IsLetter(r) })
}

// ---------------------------------------------------------------- wc

// wc: word count.
func wcMap(filename, contents string) []mr.KeyValue {
	var kvs []mr.KeyValue
	for _, w := range words(contents) {
		kvs = append(kvs, mr.KeyValue{Key: w, Value: "1"})
	}
	return kvs
}

func wcReduce(key string, values []string) string {
	return strconv.Itoa(len(values))
}

// ----------------------------------------------------------- indexer

// indexer: for each word, which files contain it. Output: "N file1,file2,..."
func indexerMap(filename, contents string) []mr.KeyValue {
	seen := map[string]bool{}
	var kvs []mr.KeyValue
	for _, w := range words(contents) {
		if !seen[w] {
			seen[w] = true
			kvs = append(kvs, mr.KeyValue{Key: w, Value: filename})
		}
	}
	return kvs
}

func indexerReduce(key string, values []string) string {
	vs := append([]string(nil), values...)
	sort.Strings(vs)
	return fmt.Sprintf("%d %s", len(vs), strings.Join(vs, ","))
}

// ------------------------------------------------------- test helpers

// logEvent appends one line to $MR_LOGDIR/<file>. Used by tests to observe
// what the workers did. A single small O_APPEND write is atomic enough.
func logEvent(file, line string) {
	dir := os.Getenv("MR_LOGDIR")
	if dir == "" {
		return
	}
	f, err := os.OpenFile(filepath.Join(dir, file), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	fmt.Fprintf(f, "%s\n", line)
	f.Close()
}

// timing: Map and Reduce sleep and log start/end times so tests can measure
// how many ran at once. Map emits 8 fixed keys k0..k7 (value "1").
func timingMap(filename, contents string) []mr.KeyValue {
	logEvent("timing.log", fmt.Sprintf("map start %d", time.Now().UnixNano()))
	time.Sleep(1 * time.Second)
	logEvent("timing.log", fmt.Sprintf("map end %d", time.Now().UnixNano()))
	var kvs []mr.KeyValue
	for i := 0; i < 8; i++ {
		kvs = append(kvs, mr.KeyValue{Key: fmt.Sprintf("k%d", i), Value: "1"})
	}
	return kvs
}

func timingReduce(key string, values []string) string {
	logEvent("timing.log", fmt.Sprintf("reduce start %d", time.Now().UnixNano()))
	time.Sleep(500 * time.Millisecond)
	logEvent("timing.log", fmt.Sprintf("reduce end %d", time.Now().UnixNano()))
	return strconv.Itoa(len(values))
}

// jobcount: word count that logs every Map call (per file) and Reduce call
// (per key) so tests can detect extra, unnecessary executions.
func jobcountMap(filename, contents string) []mr.KeyValue {
	logEvent("jobs.log", "map "+filename)
	time.Sleep(500 * time.Millisecond)
	return wcMap(filename, contents)
}

func jobcountReduce(key string, values []string) string {
	logEvent("jobs.log", "reduce "+key)
	return wcReduce(key, values)
}

// crash: word count whose workers randomly die (os.Exit) or stall for much
// longer than the task timeout. Tests your timeout + re-issue logic and your
// handling of late duplicate completions.
var rng = rand.New(rand.NewSource(time.Now().UnixNano() ^ int64(os.Getpid())))

// per-thousand probabilities
func maybeCrash(crashPerK, stallPerK int) {
	r := rng.Intn(1000)
	if r < crashPerK {
		os.Exit(1)
	} else if r < crashPerK+stallPerK {
		time.Sleep(3 * mr.TaskTimeout())
	}
}

func crashMap(filename, contents string) []mr.KeyValue {
	maybeCrash(300, 100)
	return wcMap(filename, contents)
}

func crashReduce(key string, values []string) string {
	maybeCrash(40, 10) // reduce is called once per key, so keep this low
	return wcReduce(key, values)
}
