// Command mr runs one role of the MapReduce system.
//
//	mr -role=coordinator -addr=127.0.0.1:8000 -nreduce=10 file1.txt file2.txt ...
//	mr -role=worker      -coord=127.0.0.1:8000 -app=wc
//	mr -role=sequential  -app=wc file1.txt file2.txt ...   (reference answer)
package main

import (
	"flag"
	"fmt"
	"log"
	"os"
	"time"

	"mapreduce/apps"
	"mapreduce/mr"
)

func main() {
	log.SetFlags(log.Ltime | log.Lmicroseconds)

	role := flag.String("role", "", "coordinator | worker | sequential")
	addr := flag.String("addr", "127.0.0.1:8000", "coordinator: address to listen on")
	coord := flag.String("coord", "127.0.0.1:8000", "worker: coordinator address")
	nReduce := flag.Int("nreduce", 10, "coordinator: number of reduce tasks")
	appName := flag.String("app", "wc", fmt.Sprintf("application: %v", apps.Names()))
	flag.Parse()
	files := flag.Args()

	switch *role {
	case "coordinator":
		if len(files) == 0 {
			log.Fatal("coordinator: no input files given")
		}
		c := mr.MakeCoordinator(*addr, files, *nReduce)
		for !c.Done() {
			time.Sleep(100 * time.Millisecond)
		}
		// Give workers a moment to be told the job is over.
		time.Sleep(1 * time.Second)

	case "worker":
		app := mustApp(*appName)
		mr.Worker(*coord, app.Map, app.Reduce)

	case "sequential":
		app := mustApp(*appName)
		for _, line := range mr.RunSequential(files, app.Map, app.Reduce) {
			fmt.Println(line)
		}

	default:
		fmt.Fprintln(os.Stderr, "usage: mr -role=coordinator|worker|sequential [flags] [files...]")
		flag.PrintDefaults()
		os.Exit(2)
	}
}

func mustApp(name string) apps.App {
	a, ok := apps.Get(name)
	if !ok {
		log.Fatalf("unknown app %q (have %v)", name, apps.Names())
	}
	return a
}
